# Fridge_Food > 2023-07-25 4:48pm
https://universe.roboflow.com/dsstudy/fridge_food-woibx

Provided by a Roboflow user
License: MIT

